<?php
    $name = $_POST['user_name'];
    $phone = $_POST['user_phone'];
    $mas = $_POST['massenge'];
    echo "JOB! <br>". $name . "<br>". $phone . "<br>". $mas;
?>